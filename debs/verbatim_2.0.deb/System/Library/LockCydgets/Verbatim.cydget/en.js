/*********************************************

TIP FOR THE PROS:
--- You can use html tags
    to improve your Verbatim text:
    See the example bellow:

    MSG_SINGULAR_EMAIL = "<i>%</i> unread e-mail"
        
        or, for colouring it:

     MSG_SINGULAR_EMAIL = "<font color='red'>%</font> unread e-mail"

*********************************************/

var
ERROR_WORD = "error!",
ERROR_INTERJECTION = "Oh oh.",
WRONG_CITY_CODE = "wrong city code",
NO_CITY_CODE = "no city code defined",
CONNECTION_PROBLEM = "connection problem",

WELCOME_SP1 = "Welcome to Verbatim! It's our first time together, so let me help you!",
WELCOME_SP2 = "1st: Go to your Settings App! ... 2nd: You can customize your lock screen appearance. All information you need, will be displayed by me, and 3rd: check out, the Settings app for more customization details, and there, you can get my developer contact information, for any troubleshooting.",
WELCOME_SP3 = "Enjoy this clean experience!",

WELCOME_TXT0 = "Welcome to <b>Verbatim</b>!",
WELCOME_TXT1 = "<b>PLEASE</b>! Listen to me.",
WELCOME_TXT2 = "Setup your city at Weather App",
WELCOME_TXT3 = "The available <b>options</b> are:",
WELCOME_TXT4 = "- Text <b>animations</b> like this one",
WELCOME_TXT5 = "- <b>Change</b> text color to match a theme",
WELCOME_TXT6 = "<b>Suggestion</b>: hide lock screen stuff",
WELCOME_TXT7 = "like <b>slide to unlock</b> text,",
WELCOME_TXT8 = "or simply <b>customize</b> it",

HOUR_AM = "morning",
HOUR_PM = "afternoon",

MSG_SINGULAR_EMAIL = "<b>%</b> unread e-mail",
MSG_PLURAL_EMAIL = "<b>%</b> unread e-mails",

MSG_SINGULAR_APPS = "<b>%</b> app to update",
MSG_PLURAL_APPS = "<b>%</b> pending updates",

MSG_SINGULAR_SMS = "<b>%</b> message to read",
MSG_PLURAL_SMS = "<b>%</b> messages to read",

MSG_SINGULAR_CALLS = "also, <b>%</b> missed call",
MSG_PLURAL_CALLS = "also, <b>%</b> missed calls",

MSG_BATTERY_ALMOST_FULL = " <b>almost</b> fully charged battery",
MSG_BATTERY_FULL_PLUGGED = " <b>fully</b> loaded, unplug your charger",
MSG_BATTERY_FULL = " <b>fully</b> charged",
MSG_BATTERY_CHARGING = " <b>%</b> and charging",
MSG_BATTERY_DRAINING = " <b>%</b> and draining",

/*
	! = hours
	@ = minutes
	# = seconds
*/
TIME_TEXT = "Now is: ! hours and @ minutes",

/* Use http://en.wikipedia.org/wiki/ISO_8601 for formating */
DATE_FORMAT = "EEEEdMMMM",


end_of_definitions = 'en'; 


WEATHER_CONDITION = [
"tornado",
"tropical storm",
"hurricane",
"severe thunderstorms",
"thunderstorms",
"mixed rain and snow",
"mixed rain and sleet",
"mixed snow and sleet",
"freezing drizzle",
"drizzle",
"freezing rain",
"showers",
"showers",
"snow flurries",
"light snow showers",
"blowing snow",
"snow",
"hail",
"sleet",
"dust",
"foggy",
"haze",
"smoky",
"blustery",
"windy",
"cold",
"cloudy",
"mostly cloudy", /* night */
"mostly cloudy", /* day */ 
"partly cloudy", /* night */
"partly cloudy", /* day */ 
"clear", /* night */
"sunny",
"fair", /* night */
"fair", /* day */ 
"mixed rain and hail",
"hot",
"isolated thunderstorms",
"scattered thunderstorms",
"scattered thunderstorms",
"scattered showers",
"heavy snow",
"scattered snow showers",
"heavy snow",
"partly cloudy",
"thundershowers",
"snow showers",
"isolated thundershowers"];

WEATHER_CONDITION[3200] ="not available";
/*
	(star 		*	condition)
	(percent	%	temperature)
	(sharp		#	city name)
*/
var
WEATHER_TXT = "<b>*</b> at <b>%</b>",
WEATHER_ICON_LINE = " in <b>#</b>",
WEATHER_DEGREE = "degrees";
