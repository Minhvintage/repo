/*********************************************

TIP FOR THE PROS:
--- You can use html tags
    to improve your Verbatim text:
    See the example bellow:

    MSG_SINGULAR_EMAIL = "<i>%</i> unread e-mail"
        
        or, for colouring it:

     MSG_SINGULAR_EMAIL = "<font color='red'>%</font> unread e-mail"

*********************************************/

var
ERROR_WORD = "错误!",
ERROR_INTERJECTION = "错误.",
WRONG_CITY_CODE = "不正确城市密码",
NO_CITY_CODE = "没输入城市密码",
CONNECTION_PROBLEM = "连接问题",

WELCOME_SP1 = "欢迎使用 Verbatim! 这是我们第一次见面, 让我来指导你吧!",
WELCOME_SP2 = "首先: 请确认您在设置里输入了城市密码，为了收取天气预报! ... 第二: 为了节省空间，你能把 status bar 藏. 其实呢, 你所需要的讯息我都会让你知道, 最后: 请查看怎么设定您的手机在设置, 也能找到联络我的详情f.",
WELCOME_SP3 = "请享用",

WELCOME_TXT0 = "欢迎使用 <b>Verbatim</b>!",
WELCOME_TXT1 = "<b>请</b>! 听我说.",
WELCOME_TXT2 = "S在 <b>设置</b> 里输入城市密码",
WELCOME_TXT3 = "The available <b>options</b> are:",
WELCOME_TXT4 = "- 文字 <b>动画</b> 像这样",
WELCOME_TXT5 = "- <b>藏</b> status bar 为了节省空间",
WELCOME_TXT6 = "<b>提议</b>: 藏锁屏设定",
WELCOME_TXT7 = "喜欢 <b>滑动来解锁</b> 文字吗？",
WELCOME_TXT8 = "还是把它 <b>换</b> 了",

MSG_SINGULAR_EMAIL = "<b>%</b> 未读电邮",
MSG_PLURAL_EMAIL = "<b>%</b> 未读电邮",

MSG_SINGULAR_APPS = "<b>%</b> 一个程序未更新",
MSG_PLURAL_APPS = "<b>%</b> 一些程序未更新",

MSG_SINGULAR_SMS = "<b>%</b> 未读简讯",
MSG_PLURAL_SMS = "<b>%</b> 未读简讯",

MSG_SINGULAR_CALLS = "also, <b>%</b> 未接来电",
MSG_PLURAL_CALLS = "also, <b>%</b> 未接来电",

MSG_BATTERY_ALMOST_FULL = " <b>almost</b> 电池充满",
MSG_BATTERY_FULL_PLUGGED = " <b>fully</b> 充满, 请把充电器关掉",
MSG_BATTERY_FULL = " <b>充满</b>",
MSG_BATTERY_CHARGING = " <b>%</b> 在充",
MSG_BATTERY_DRAINING = " <b>%</b> 在失去",

TIME_TEXT = "现在有!个小时@分钟",

/* Use http://en.wikipedia.org/wiki/ISO_8601 for formating */
DATE_FORMAT = "EEEEdMMMM",


end_of_definitions = 'zh'; 


WEATHER_CONDITION = [
"龙卷风",
"强风暴雨",
"台风",
"严重暴雨",
"雷雨交加",
"下雨和雪",
"下雨雪",
"暴风雪",
"冷雨",
"细雨",
"冷雨",
"大雨",
"大雨",
"雪阵",
"小暴风雪",
"狂风加雪",
"下雪",
"冰雪",
"雨雪",
"小雾",
"大雾",
"霾",
"熏",
"坏天气",
"强风",
"冷",
"多云",
"多云",
"多云",
"多云",
"多云",
"晴",
"晴朗",
"多云",
"多云",
"雨加冰刨",
"炎日",
"安定雨",
"稀雨",
"安定暴雨",
"稀暴雨",
"强雪",
"稀雪",
"强雪",
"多云",
"雷雨",
"强雨雪",
"安定雷雨"];

WEATHER_CONDITION[3200] ="不可用";
/*
	(star 		*	condition)
	(percent	%	temperature)
	(sharp		#	city name)
*/
var
WEATHER_TXT = "<b>*</b> 至 <b>%</b>",
WEATHER_ICON_LINE = " 在 <b>#</b>",
WEATHER_DEGREE = "度";
