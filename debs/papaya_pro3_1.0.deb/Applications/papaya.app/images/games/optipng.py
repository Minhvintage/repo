import os
p = r'.'
for i in os.listdir(p):
    if i.lower().endswith('.png'):
        os.system('pngout '+i)
        os.system('pngout -c2 '+i)
        os.system('pngout -c3 '+i)
raw_input()
